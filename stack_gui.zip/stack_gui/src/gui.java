import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class gui extends JFrame {

    private final int MAX = 6;
    private String[] stack = new String[MAX];
    private int top = -1;

    private JPanel stackContainer;
    private JLabel resultLabel;
    private JTextField input;

    public gui() {

        setTitle("STACK VISUALIZER 😃");
        setSize(470, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLayout(new BorderLayout());
        getContentPane().setBackground(Color.WHITE);

        // ---------------- TOP TITLE ----------------
        JLabel title = new JLabel("Stacks");
        title.setFont(new Font("Segoe UI", Font.BOLD, 28));
        title.setBorder(BorderFactory.createEmptyBorder(20, 20, 0, 0));
        add(title, BorderLayout.NORTH);

        // ---------------- MAIN PANEL ----------------
        JPanel main = new JPanel();
        main.setLayout(new BoxLayout(main, BoxLayout.Y_AXIS));
        main.setBackground(Color.WHITE);
        main.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel desc = new JLabel("A stack is a data structure that can hold many elements.");
        desc.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        main.add(desc);
        main.add(Box.createRigidArea(new Dimension(0, 20)));

        // ---------------- STACK BOX ----------------
        JPanel stackBox = new JPanel();
        stackBox.setPreferredSize(new Dimension(300, 350));
        stackBox.setBackground(Color.WHITE);
        stackBox.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2));
        stackBox.setLayout(new BorderLayout());

        stackContainer = new JPanel();
        stackContainer.setLayout(new GridLayout(MAX, 1, 6, 6));
        stackContainer.setBackground(Color.WHITE);
        stackContainer.setBorder(BorderFactory.createEmptyBorder(20, 60, 20, 60));

        for (int i = 0; i < MAX; i++)
            stackContainer.add(createEmptySlot());

        stackBox.add(stackContainer, BorderLayout.CENTER);
        main.add(stackBox);

        // Result Label
        resultLabel = new JLabel("Result:");
        resultLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        resultLabel.setBorder(BorderFactory.createEmptyBorder(15, 0, 0, 0));
        main.add(resultLabel);
        main.add(Box.createRigidArea(new Dimension(0, 20)));

        // ---------------- BUTTON PANEL ----------------
        JPanel buttons = new JPanel(new GridLayout(2, 3, 12, 12));
        buttons.setBackground(Color.WHITE);

        JButton pushBtn = createW3Button("push()");
        JButton popBtn = createW3Button("pop()");
        JButton peekBtn = createW3Button("peek()");
        JButton emptyBtn = createW3Button("isEmpty()");
        JButton sizeBtn = createW3Button("size()");

        input = new JTextField();
        input.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        input.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));

        buttons.add(pushBtn);
        buttons.add(popBtn);
        buttons.add(peekBtn);
        buttons.add(emptyBtn);
        buttons.add(sizeBtn);
        buttons.add(input);

        main.add(buttons);

        add(main, BorderLayout.CENTER);

        // ---------------- BUTTON ACTIONS ----------------

        pushBtn.addActionListener(e -> push());
        popBtn.addActionListener(e -> pop());
        peekBtn.addActionListener(e -> peek());
        emptyBtn.addActionListener(e -> checkEmpty());
        sizeBtn.addActionListener(e -> checkSize());
    }

    // ---------------- W3Schools-style Rounded Button ----------------
    private JButton createW3Button(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btn.setBackground(new Color(245, 245, 245));
        btn.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        btn.setFocusPainted(false);

        btn.setUI(new javax.swing.plaf.basic.BasicButtonUI());

        btn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.GRAY),
                BorderFactory.createEmptyBorder(8, 15, 8, 15)
        ));

        // Hover effect
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(new Color(230, 230, 230));
            }

            public void mouseExited(MouseEvent e) {
                btn.setBackground(new Color(245, 245, 245));
            }
        });

        return btn;
    }

    // ---------------- EMPTY SLOT FOR STACK ----------------
    private JPanel createEmptySlot() {
        JPanel p = new JPanel();
        p.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 2));
        p.setBackground(Color.WHITE);
        return p;
    }

    // ---------------- VALUE BOX (PANCAKE) ----------------
    private JPanel createValueBox(String val) {
        JPanel p = new JPanel();
        p.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 2));
        p.setBackground(new Color(240, 240, 240));
        JLabel lbl = new JLabel(val);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 15));
        p.add(lbl);
        return p;
    }

    // ---------------- UPDATE VISUAL STACK ----------------
    private void animatePush(JPanel box) {
        Timer timer = new Timer(10, null);
        Point start = new Point(box.getX(), box.getY() - 40);
        box.setLocation(start);

        timer.addActionListener(new ActionListener() {
            int step = 0;

            public void actionPerformed(ActionEvent e) {
                step++;
                box.setLocation(box.getX(), box.getY() + 2);
                if (step > 20) timer.stop();
            }
        });
        timer.start();
    }

    private void refreshStack() {
        stackContainer.removeAll();
        for (int i = 0; i < MAX; i++) {
            if (i <= top && stack[i] != null) {
                JPanel valueBox = createValueBox(stack[i]);
                stackContainer.add(valueBox);
            } else {
                stackContainer.add(createEmptySlot());
            }
        }
        stackContainer.revalidate();
        stackContainer.repaint();
    }

    // ---------------- STACK LOGIC ----------------
    private void push() {
        String value = input.getText().trim();

        if (value.isEmpty()) {
            resultLabel.setText("Result: Enter a value");

            return;
        }
        if (top == MAX - 1) {
            resultLabel.setText("Result: Stack Overflow");
            return;
        }

        top++;
        stack[top] = value;
        refreshStack();
        resultLabel.setText("Result: Pushed " + value);

        input.setText("");
    }

    private void pop() {
        if (top == -1) {
            resultLabel.setText("Result: Stack Underflow");
            return;
        }

        String removed = stack[top];
        stack[top] = null;
        top--;

        refreshStack();
        resultLabel.setText("Result: Popped " + removed);
    }

    private void peek() {
        if (top == -1) {
            resultLabel.setText("Result: Stack is empty");
        } else {
            resultLabel.setText("Result: Top = " + stack[top]);
        }
    }

    private void checkEmpty() {
        resultLabel.setText("Result: " + (top == -1 ? "true" : "false"));
    }

    private void checkSize() {
        resultLabel.setText("Result: " + (top + 1));
    }


}
